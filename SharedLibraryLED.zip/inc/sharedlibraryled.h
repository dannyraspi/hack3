#ifndef _SHAREDLIBRARYLED_H_
#define _SHAREDLIBRARYLED_H_

/**
 * This header file is included to define _EXPORT_.
 */
#include <stdbool.h>
#include <tizen.h>

#ifdef __cplusplus
extern "C" {
#endif

// This method is exported from sharedlibraryled.so
EXPORT_API void led1_init(void);
EXPORT_API void led1_terminate(void);
EXPORT_API void led1_on(void);
EXPORT_API void led1_off(void);

EXPORT_API void led2_init(void);
EXPORT_API void led2_terminate(void);
EXPORT_API void led2_on(void);
EXPORT_API void led2_off(void);

EXPORT_API void led3_init(void);
EXPORT_API void led3_terminate(void);
EXPORT_API void led3_on(void);
EXPORT_API void led3_off(void);

EXPORT_API void led4_init(void);
EXPORT_API void led4_terminate(void);
EXPORT_API void led4_on(void);
EXPORT_API void led4_off(void);

EXPORT_API void fan1_init(void);
EXPORT_API void fan1_terminate(void);
EXPORT_API void fan1_on(void);
EXPORT_API void fan1_off(void);

EXPORT_API void fan2_init(void);
EXPORT_API void fan2_terminate(void);
EXPORT_API void fan2_on(void);
EXPORT_API void fan2_off(void);

#ifdef __cplusplus
}
#endif
#endif // _SHAREDLIBRARYLED_H_

