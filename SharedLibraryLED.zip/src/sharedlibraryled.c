/**
 * This file contains the exported symbol.
 */
#include "sharedlibraryled.h"
#include <peripheral_io.h>

#define SENSOR_LED_GPIO_NUMBER1 (22)
#define SENSOR_LED_GPIO_NUMBER2 (23)
#define SENSOR_LED_GPIO_NUMBER3 (24)
#define SENSOR_LED_GPIO_NUMBER4 (25)
#define SENSOR_FAN_GPIO_NUMBER5 (7)    //Fan left
#define SENSOR_FAN_GPIO_NUMBER6 (8)    //Fan right
peripheral_gpio_h g_sensor_h1 = NULL;
peripheral_gpio_h g_sensor_h2 = NULL;
peripheral_gpio_h g_sensor_h3 = NULL;
peripheral_gpio_h g_sensor_h4 = NULL;
peripheral_gpio_h g_sensor_h5 = NULL;  //Fan
peripheral_gpio_h g_sensor_h6 = NULL;  //Fan

void led1_init(){
    peripheral_gpio_open(SENSOR_LED_GPIO_NUMBER1, &g_sensor_h1);
    peripheral_gpio_set_direction(g_sensor_h1, PERIPHERAL_GPIO_DIRECTION_OUT_INITIALLY_LOW);
}

void led1_terminate(){
    peripheral_gpio_close(g_sensor_h1);
    g_sensor_h1 = NULL;
}

void led1_on(){
    peripheral_gpio_write(g_sensor_h1, 1);
}

void led1_off(){
    peripheral_gpio_write(g_sensor_h1, 0);
}

void led2_init(){
    peripheral_gpio_open(SENSOR_LED_GPIO_NUMBER2, &g_sensor_h2);
    peripheral_gpio_set_direction(g_sensor_h2, PERIPHERAL_GPIO_DIRECTION_OUT_INITIALLY_LOW);
}

void led2_terminate(){
    peripheral_gpio_close(g_sensor_h2);
    g_sensor_h2 = NULL;
}

void led2_on(){
    peripheral_gpio_write(g_sensor_h2, 1);
}

void led2_off(){
    peripheral_gpio_write(g_sensor_h2, 0);
}

void led3_init(){
    peripheral_gpio_open(SENSOR_LED_GPIO_NUMBER3, &g_sensor_h3);
    peripheral_gpio_set_direction(g_sensor_h3, PERIPHERAL_GPIO_DIRECTION_OUT_INITIALLY_LOW);
}

void led3_terminate(){
    peripheral_gpio_close(g_sensor_h3);
    g_sensor_h3 = NULL;
}

void led3_on(){
    peripheral_gpio_write(g_sensor_h3, 1);
}

void led3_off(){
    peripheral_gpio_write(g_sensor_h3, 0);
}

void led4_init(){
    peripheral_gpio_open(SENSOR_LED_GPIO_NUMBER4, &g_sensor_h4);
    peripheral_gpio_set_direction(g_sensor_h4, PERIPHERAL_GPIO_DIRECTION_OUT_INITIALLY_LOW);
}

void led4_terminate(){
    peripheral_gpio_close(g_sensor_h4);
    g_sensor_h4 = NULL;
}

void led4_on(){
    peripheral_gpio_write(g_sensor_h4, 1);
}

void led4_off(){
    peripheral_gpio_write(g_sensor_h4, 0);
}

void fan1_init(){
    peripheral_gpio_open(SENSOR_FAN_GPIO_NUMBER5, &g_sensor_h5);
    peripheral_gpio_set_direction(g_sensor_h5, PERIPHERAL_GPIO_DIRECTION_OUT_INITIALLY_LOW);
}

void fan1_terminate(){
    peripheral_gpio_close(g_sensor_h5);
    g_sensor_h5 = NULL;
}

void fan1_on(){
    peripheral_gpio_write(g_sensor_h5, 1);
}

void fan1_off(){
    peripheral_gpio_write(g_sensor_h5, 0);
}

void fan2_init(){
    peripheral_gpio_open(SENSOR_FAN_GPIO_NUMBER6, &g_sensor_h6);
    peripheral_gpio_set_direction(g_sensor_h6, PERIPHERAL_GPIO_DIRECTION_OUT_INITIALLY_LOW);
}

void fan2_terminate(){
    peripheral_gpio_close(g_sensor_h6);
    g_sensor_h6 = NULL;
}

void fan2_on(){
    peripheral_gpio_write(g_sensor_h6, 1);
}

void fan2_off(){
    peripheral_gpio_write(g_sensor_h6, 0);
}
